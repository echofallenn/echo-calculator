import tkinter as tk

def button_click(value):
    current = display.get()
    display.delete(0, tk.END)
    display.insert(0, current + value)

def button_clear():
    display.delete(0, tk.END)

def button_equal():
    try:
        result = eval(display.get())
        display.delete(0, tk.END)
        display.insert(0, str(result))
    except:
        display.delete(0, tk.END)
        display.insert(0, "Error")

# Initialize the main window
root = tk.Tk()
root.title("echofallenn's Calculator (feat. ChatGPT)")
root.config(bg="#2b2b2b")
root.geometry("400x500")

# Create the display widget
display_font = ("Arial", 28)  # Default font
display = tk.Entry(root, width=20, font=display_font, bd=0, bg="#2b2b2b", fg="white", justify='right', insertbackground="white")
display.grid(row=0, column=0, columnspan=4, ipady=20, pady=10)

# Define button layout
buttons = [
    ('7', 1, 0), ('8', 1, 1), ('9', 1, 2), ('/', 1, 3),
    ('4', 2, 0), ('5', 2, 1), ('6', 2, 2), ('*', 2, 3),
    ('1', 3, 0), ('2', 3, 1), ('3', 3, 2), ('-', 3, 3),
    ('0', 4, 0), ('.', 4, 1), ('=', 4, 2), ('+', 4, 3),
]

# Create and place the buttons
button_font = ("Arial", 18)  # Default font
for (text, row, col) in buttons:
    button_style = {
        "font": button_font,
        "bd": 0,
        "fg": "white",
        "bg": "#333333",
        "activebackground": "#666666",
        "activeforeground": "white",
        "height": 2,
        "width": 4,
        "relief": "flat"
    }
    if text == "=":
        btn = tk.Button(root, text=text, command=button_equal, **button_style)
    else:
        btn = tk.Button(root, text=text, command=lambda txt=text: button_click(txt), **button_style)
    btn.grid(row=row, column=col, padx=5, pady=5, sticky='nsew')

# Clear button with orange color
clear_button = tk.Button(root, text="C", command=button_clear, font=button_font, bd=0, fg="white", bg="#FFA500", 
                         activebackground="#FFB84D", activeforeground="white", height=2, width=8, relief="flat")
clear_button.grid(row=5, column=0, columnspan=2, padx=5, pady=5, sticky='nsew')

# Adjust grid weights for proper alignment
for i in range(4):
    root.grid_columnconfigure(i, weight=1)
for i in range(6):
    root.grid_rowconfigure(i, weight=1)

# Run the application
root.mainloop()
