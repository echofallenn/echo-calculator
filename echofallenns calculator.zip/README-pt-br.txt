BEM-VINDO!

eu fiz essa calculadora só por diversão, mas no final demorou duas horas pra compilar e corrigir bugs ;-;
use a vontade, e eu ia ficar bem feliz se alguém usasse isso como a calculadora principal kkkkk

tchau, se divirta!