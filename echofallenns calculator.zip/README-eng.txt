WELCOME!

i made this calculator just for fun, and it took me 2 hours to compile and fix errors ;-;
enjoy it, i'd be happy if you somehow make this your primary calculator lol


byee, have fun!